
import json

from typing_extensions import Optional

import udi_interface, os, shutil, threading
LOGGER = udi_interface.LOGGER
Custom = udi_interface.Custom
polyglot = udi_interface.Interface([])
from typing import Dict, Union, List
from ioxplugin import Plugin, OAuthService
import aiohttp
from datetime import datetime, date
import asyncio

DATA_PATH='./data'
HEBCAL_BASE_URL = "https://www.hebcal.com/hebcal"
HEBCAL_CONVERTER_URL = "https://www.hebcal.com/converter"
from HebcalNode import HebcalNode
class HebcalControllerNode(udi_interface.Node):
    id = 'hebcalcontroll'
    """This is a list of properties that were defined in the nodedef"""
    drivers = [{'driver': 'ST', 'value': 0, 'uom': 25, 'name': 'Status'}]
    children = [{'node_class': 'HebcalNode', 'id': 'hebcal', 'name':
        'Hebcal', 'parent': 'hebcalcontroll'}]

    def __init__(self, polyglot, plugin, controller='hebcalcontroll',
        address='hebcalcontroll', name='Hebcal Controller'):
        super().__init__(polyglot, controller, address, name)
        self.plugin = plugin
        self.Parameters = Custom(polyglot, 'customparams')
        self.poly.addNode(self, conn_status='ST')
        self.oauthService = None
        self.poly.subscribe(polyglot.START, self.__start, address)
        self.poly.subscribe(polyglot.CUSTOMPARAMS, self.parameterHandler)
        self.poly.subscribe(polyglot.POLL, self.__poll)
        self.poly.subscribe(polyglot.STOP, self.__stop)
        self.poly.subscribe(polyglot.CONFIG, self.__configHandler)
        self.poly.subscribe(polyglot.CONFIGDONE, self.__configDoneHandler)
        self.poly.subscribe(polyglot.ADDNODEDONE, self.__addNodeDoneHandler)
        self.poly.subscribe(polyglot.DELNODEDONE, self.__removeNodeDoneHandler)
        self.poly.subscribe(polyglot.CUSTOMNS, self.__customNSHandler)
        self.poly.subscribe(polyglot.CUSTOMDATA, self.customDataHandler)
        self.poly.subscribe(polyglot.DISCOVER, self.discover)
        self.poly.subscribe(polyglot.BONJOUR, self.__bonjourHandler)
        self.poly.subscribe(polyglot.CUSTOMREQUEST, self.handle_custom_request)
        self.configDone = threading.Condition()
        self.__initOAuth()
        self.configDoneAlready = False

    def getUOM(self, driver: str):
        try:
            for driver_def in self.drivers:
                if driver_def['driver'] == driver:
                    return driver_def['uom']
            return None
        except Exception as ex:
            return None

    def __initOAuth(self):
        if self.plugin and self.plugin.meta and self.plugin.meta.getEnableOAUTH2():
            self.oauthService = OAuthService(self.polyglot)
            self.poly.subscribe(polyglot.OAUTH, self.__oauthHandler)

    def __configHandler(self, param):
        try:
            if os.path.exists(DATA_PATH):
                self.filesUploaded(DATA_PATH)
                shutil.rmtree(DATA_PATH)
            if param:
                return self.processConfig(param)
        except Exception as ex:
            LOGGER.warn(str(ex))

        return True

    def __bonjourHandler(self, message):
        try:
            command = message['command']
            if command == None or command != "bonjour": 
                return
            mdns = message['mdns']
            self.processMDNSResults(mdns)
        except Exception as ex:
            LOGGER.error(str(ex))

    def __start(self):
        LOGGER.info(f'Starting... ')
        try:
            self.poly.setCustomParamsDoc()
            if not self.configDoneAlready:
                with self.configDone:
                    result = self.configDone.wait(timeout=10)
                    if not result:
                        #timedout
                        LOGGER.info("timed out while waiting for configDone")
                        self.__updateStatus(0, True) 
                        return False
            if self.start():
                self.__addAllNodes()
                self.poly.updateProfile()
                self.__updateStatus(1, True) 
                return True
            else:
                LOGGER.info("failed processing config ...")
                self.__updateStatus(0, True) 
                return False
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def __stop(self):
        LOGGER.info(f'Stopping ... ')
        self.stop()
        self.__updateStatus(0,True)
        return True

    def __poll(self, polltype):
        if not self.configDoneAlready:
            return
        if 'shortPoll' in polltype:
            self.shortPoll()
        elif 'longPoll' in polltype:
            self.longPoll()

    def __addAllNodes(self):
        config = self.poly.getConfig()
        if config is None or config['nodes'] is None or len(config['nodes']) <= 0:
            config = {}
            config['nodes'] = []

        if self.plugin.areNodesStatic():
            for child in self.children:
                try:
                    config['nodes'].append({'nodeDefId': child['id'], 'address':
                    child['id'], 'name': child['name'],
                    'primaryNode': child['parent']})
                except Exception as ex:
                    LOGGER.error(str(ex))
                    return

        for node in config['nodes']:
            if node['nodeDefId'] == self.id:
                continue
            if not self.__addNodeFromConfig(node):
                return
        LOGGER.info(f'Done adding nodes ...')
    
    def __getNodeClass(self, nodeDefId:str)->str:
        for child in self.children:
            if child['id'] == nodeDefId:
                return child['node_class']
        return None

    def __addNodeFromConfig(self, node_info) ->bool:
        if node_info is None:
            LOGGER.error('node cannot be null')
            return False
        try:
            node_class = self.__getNodeClass(node_info['nodeDefId'])
            if node_class == None:
                return False 
            node_address=self.getNodeAddress(node_info['nodeDefId'])
            cls = globals()[node_class]
            node = cls(self.poly, self.plugin, node_info['primaryNode'], node_address, node_info['name'])
            if node is None:
                LOGGER.error(f'invalid noddef id ...')
                return False
            else:
                node_r = self.poly.addNode(node)
                if node_r:
                    return True
                LOGGER.error("failed adding node ... ") 
                return False
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def __addNodeDoneHandler(self, node):
        try:
            if node['nodeDefId'] == self.id:
                return True
            return self.addNodeDone(node)

        except ValueError as err:
            LOGGER.error(str(err))
            return False

    def __removeNodeDoneHandler(self, node):
        try:
            if node['nodeDefId'] == self.id:
                return True
            return self.nodeRemoved(node)

        except ValueError as err:
            LOGGER.error(str(err))
            return False

    def __configDoneHandler(self):
        rc = False
        if self.oauthService:
            # First check if user has authenticated
            try:
                self.oauthService.getAccessToken()
                # If getAccessToken did raise an exception, then proceed with device discovery
                rc = self.processConfigDone()

            except ValueError as err:
                LOGGER.warning('Access token is not yet available. Please authenticate.')
                polyglot.Notices['auth'] = 'Please initiate authentication using the Authenticate Buttion'
                return False
        with self.configDone:
            self.configDoneAlready = True
            self.configDone.notifyAll()
        return rc

    def __customNSHandler(self, key, data):
        if key == 'oauth':
            # This provides the oAuth config (key='oauth') and saved oAuth tokens (key='oauthTokens))
            if not self.oauthService:
                return 
            try:
                self.oauthService.customNsHandler(key, data)
            except Exception as ex:
                LOGGER.error(ex)
        else:
            self.customParamHandler(key, data)

    def __oauthHandler(self, token):
        if not self.oauthService:
            return 
        # This provides the oAuth config (key='oauth') and saved oAuth tokens (key='oauthTokens))
        try:
            self.oauthService.oauthHandler(token)
        except Exception as ex:
            LOGGER.error(ex)


    def __updateStatus(self, value, force: bool):
        return self.setDriver("ST", value, 2, force)

    def __getStatus(self):
        return self.getDriver("ST")

    def __query(self, command):
        nodes = self.poly.getNodes()
        if nodes is None or len(nodes) == 0:
            return True
        for n in nodes:
            node = nodes[n]
            if node is None:
                continue
            else:
                node.query()

    #######################
    ###### NOTICES ########
    #######################
    def clearNotices(self):
        """
        Call this method to remove the blue ribbon that requests the attention of the user
        """
        self.poly.Notices.clear()

    def setNotices(self, key:str, notice:str) :
        """
        Call this method to add a blue ribbon with notice for the customer to take action
        This is a dictionary. So, you would need to provide the key (i.e. the parameter's name)
        And a string that will be displayed in the ribbon
        """
        if key == None or notice == None:
            LOGGER.error("setNotices requires both the key and the notice.")
            return
        self.poly.Notices[key]=notice

    #####################
    ###### NODES ########
    #####################

    def getNode(self, address:str):
        """
        Call this method to get a node and then call its methods for updating
        their state in IoX. Take a look at the class that implements this node
        it's always a good idea to use isinstance to make sure you are dealing 
        with the correct node.
        The address is the address of the node.
        """
        return self.poly.getNode(address)

    
    def addNode(self, address:str, nodeDefId:str, name:str, parent:str=None):
        """
        "Call this method to create dynamic node. The parent will always be the controller 
        "for this node
        """
        if address == None or nodeDefId == None:
            LOGGER.error("need address and nodeDefId ...")
            return False

        if parent == None:
            parent = address  

        nodeInfo={}
        nodeInfo['primaryNode']=parent
        nodeInfo['address']=address
        nodeInfo['name']=name
        nodeInfo['nodeDefId']=nodeDefId
        return self.__addNodeFromConfig(nodeInfo)

    #####################
    ###### OAUTH ########
    #####################

    def callOAuthApi(self, method='GET', url=None, params=None, body=None)->bool:
        """
        Use this method to call an OAUTH protected URL
        """
        if not self.oauthService:
            return False
        return self.oauthService(method, url, params, body)

    
    #############################
    ###### CUSTOM PARAMS ########
    #############################
    def createCustomParam(self, key):
        """
        Creates a user defined/custom parameter for key/value pairs of your own and stores in the 
        database. Whenever a key is updated the customParamHandler (below) is called with the 
        key and its updated value. example:
        myKey = self.createCustomParam('myKey')
        self.updateCustomParam(myKey, "my value" )
        """ 
        try:
            return Custom(self.poly, key)
        except Exception as ex:
            LOGGER.error(f'create custom param failed ...')
            return None

    def updateCustomParam(self, key:Custom, value:str):
        """
        Updates a user defined param. Whenever this method is called, customParamHandler is called
        with the updated values.
        """
        try:
            key = value
        except Exception as ex:
            LOGGER.error(f'failed updating custom param ...' )
    
    def sendPushNotification(self, title:str, body:str):
        """
        Send push notifications to UD Mobile
        """
        if title == None or body == None:
            return
        try:
            self.poly.udm_alert(title, body)
        except Exception as ex:
            LOGGER.error(str(ex))

    def __discover(self):
        return self.discover()

    ###
    # This is a list of commands that were defined in the nodedef
    ###
    commands = {'discover': __discover, 'x_query': __query}
    """########WARNING: DO NOT MODIFY THIS LINE!!! NOTHING BELOW IS REGENERATED!#########"""
    
    #############################
    ###### START|STOP ###########
    #############################
    ####

    def start(self)->bool:
        """
        MANDATORY if and only if you have commands
        This method is called at start so that you can do whatever initialization
        you need. If you return false, the status of the controller node shows 
        disconnected. So, make sure you return the correct status.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'start failed .... ')
            LOGGER.error(str(ex))
            return False

    def stop(self)->bool:
        """
        This method is called at stop so that you can do whatever cleaning up 
        that's necessary. The result is not checked so make sure everything is 
        cleaned up
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'stop failed .... ')
            return False


    #############################
    ###### PARAMS ###############
    #############################

    def parameterHandler(self, params:Custom)->bool:
        """
        This method is called with the custom parameters provided by the user.
        It is a dictionary so you get the parameter name/key and the value. e.g.
        params['path']
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'process param failed .... ')
            return False

    def customParamHandler(self, key, value):
        """
        This method is called when a custom value (key/value) pair that's stored in the 
        database is changed. You can use this method to manage custom parameters of your own
        in the database.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'process custom param failed .... ')
            return False

    def customDataHandler(self, data):
        """
        Rarely used.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(ex)
    
    #####################
    ###### NODES ########
    #####################

    def getNodeAddress(self, nodedef_id):
        """
        This method is called every time a node is added so that you can map it to 
        anything else you want. 
        """
        try:
            #do any mapping you wish. 
            return nodedef_id
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def addNodeDone(self, node)->bool:
        """
        " This method is called when adding a node to the system is completed successfully. Make sure you use isinstance
        " to ensure it's your node and then do any additional processing necessary.
        " oauth
        """
        try:
            ###You can store your nodes in a dictionary for mapping or otherwise such as
            #if node == None:
            #   return False
            #self.nodes[node.address] = node
            ###
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def nodeRemoved(self, node)->bool:
        """
        This method is called when a node as been removed from the system
        """
        try:
            ###if you stored your nodes a dictionary, delete them 
            #if node == None:
            #   return False
            #del self.nodes[node.address]
            ###
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    

    #####################
    ###### POLL #########
    #####################

    def shortPoll(self)->bool:
        """
        This method is called at every short poll interval. The result is not checked
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def longPoll(self)->bool:
        """
        This method is called at every long poll interval. The result is not checked
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False


    ##########################
    ###### FILE UPLOAD #######
    ##########################

    def filesUploaded(self, path:str)->bool:
        """
        This method is called when files are uplaoded. The path is the directory to which you can find the files
        Do whatever you need with the files because they will be removed once you are done.
        """
        try:
            pass
            ###copy files to your desired directory, something like this:
            #file_path = os.path.join(path, filename)
            #if os.path.isfile(file_path):
            #    dest_path = os.path.join('./', filename)
            #    shutil.copy(file_path, dest_path)
            ###
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    ##########################
    ###### CONFIG ############
    ##########################

    def processConfig(self, config):
        """
        This method is called upon start and gives you all the configuration parameters
        used to initialize this plugin including the store, version, etc.
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def processConfigDone(self)->bool:
        """
        This method is called with the configuration is done. This is rarely used as its main function is to facilitate 
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    #############################
    ###### DISCOVERY ############
    #############################

    def discover(self)->bool:
        """
        This method is called by IoX to discover  
        nodes/devices or service
        """
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'discover failed .... ')
            return False

    def searchForDevicesUsingMDNS(self, type:str, subtypes:str, protocol:str):
        """
        You can search the network using mDNS. To do so, call this method
        type : string = is the type of device you are looking for. If None, then everything
        subtypes : string = is a list of subtypes [string] you are looking for. If None, then everything
        protocol : string = either udp or tcp. If None, then everything
        If any results, processMDNSResults method will be called with a list of devices and their info
        """
        self.poly.bonjour(type, subtypes, protocol)

    def processMDNSResults(self, results):
        """
        If search using mDNS is successful, this method is called with an array of devices. 
        """
        try:
            # Fill out this method based on the results
            return
        except Exception as ex:
            LOGGER.error(str(ex))

    def handle_custom_request(self, request):
        """
        This method is called when a custom request is received.
        """
        try:
              # Process the custom request here
              # request is a dictionary with the following keys:    
              # 'requestId': unique identifier for the request   
              # 'payload': the payload of the request
              # To return the payload as is
              # self.poly.customResponse(data['requestId'], data['payload'])

              # To return an error message (Defaults to HTTP error 500)
              # self.poly.customResponseError(data['requestId'], 'My error message')

              # To return an error message and a custom status code
              # self.poly.customResponseError(data['requestId'], errorMessage='Request not valid', status=400)
            requestId = request.get('requestId', None)
            payload = request.get('payload', None)
            if requestId is None:
                LOGGER.error("Request not valid - missing requestId")
                return
            tool_name = payload.get('tool_name', None)
            if not tool_name:
                LOGGER.error("Missing 'tool_name' in payload")
                self.poly.customResponseError(requestId, errorMessage="Missing 'tool_name' in payload", status=400)
                return

            result = None
            if tool_name == "get_dates":
                result = asyncio.run(self._get_dates(payload))
            elif tool_name == "convert_date":
                result = asyncio.run(self._convert_date(payload))
            else:
                LOGGER.error(f"Unknown tool_name: {tool_name}")
                self.poly.customResponseError(requestId, errorMessage=f"Unknown tool_name: {tool_name}", status=400)
                return

            if result is None or len(result) == 0:
                self.poly.customResponseError(requestId, errorMessage="No data found for the given parameters", status=404)
                return

            json_result = json.dumps(result, default=str)  # Convert datetime objects to string
            self.poly.customResponse(requestId, {'result': json_result})
        except Exception as ex:
            LOGGER.error(str(ex))
            return False


    async def _get_dates( self, payload: Dict ) -> List: 
        """
        Get holidays from Hebcal API with filters.
        
        :param payload: Dictionary containing the request parameters
        :return: List of HolidayEvent objects
        """
        all_dates = []

        event_name = payload.get('event_name', None) if payload else None
        start_year = payload.get('start_year', None) if payload else None
        end_year = payload.get('end_year', None) if payload else None
        start_month = payload.get('start_month', None) if payload else None
        end_month = payload.get('end_month', None) if payload else None
        latitude = payload.get('latitude', None) if payload else None
        longitude = payload.get('longitude', None) if payload else None
        tzid = payload.get('tzid', None) if payload else None

        if end_year == None:
            end_year = start_year 
        # Fetch holidays for each year in range
        for year in range(start_year, end_year + 1):
            params = {
                "v": "1",
                "cfg": "json",
                "year": year,
                "maj": "on",  # Major holidays
                "min": "on",  # Minor holidays
                "mod": "on",  # Modern holidays
                "nx": "on",   # Rosh Chodesh
                "ss": "on",   # Special Shabbat
                "mf": "on",   # Minor fasts
                "c": "on",    # Candle lighting times
                "geo": "pos",
                "latitude": latitude,
                "longitude": longitude,
                "tzid": tzid,
            }
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(HEBCAL_BASE_URL, params=params) as response:
                        if response.status == 200:
                            data = await response.json()
                            dates = self._parse_hebcal_response(data)
                            all_dates.extend(dates)
            except Exception as e:
                # Log error but continue processing other years
                LOGGER.error(f"Error fetching Hebcal data for year {year}: {e}")
                continue
        
        all_dates = self._apply_filters(all_dates, event_name, start_month, end_month)
        return all_dates

    async def _convert_date(self, payload: dict) -> List:
        """
        Convert a Gregorian date to its Hebrew calendar equivalent using the Hebcal
        date converter REST API (https://www.hebcal.com/converter). If start_year/
        end_year are given, also project the resulting Hebrew month/day (e.g. a
        yahrzeit or birthday) onto its recurring Gregorian occurrence for every
        Hebrew year that falls within that Gregorian range.

        :param payload: Dictionary containing the following keys:
            - original_date: Gregorian date string, YYYY-MM-DD
            - start_year: Optional starting Gregorian year (inclusive)
            - end_year: Optional ending Gregorian year (inclusive)
        :return: List of conversion result dicts
        """
        original_date = payload.get('original_date', None) if payload else None
        if not original_date:
            LOGGER.error("Missing 'original_date' in payload")
            return []

        try:
            gdate = datetime.strptime(original_date, "%Y-%m-%d")
        except ValueError as ex:
            LOGGER.error(f"Invalid 'original_date' {original_date!r}, expected YYYY-MM-DD: {ex}")
            return []

        start_year = payload.get('start_year', None) if payload else None
        end_year = payload.get('end_year', None) if payload else None

        async with aiohttp.ClientSession() as session:
            hebrew = await self._gregorian_to_hebrew(session, gdate.year, gdate.month, gdate.day)
            if hebrew is None:
                return []

            if start_year is None or end_year is None:
                return [self._format_conversion_result(hebrew)]

            hebrew_month = hebrew.get("hm")
            hebrew_day = hebrew.get("hd")
            if not hebrew_month or not hebrew_day:
                LOGGER.error(f"Hebcal converter did not return hm/hd for {original_date}")
                return [self._format_conversion_result(hebrew)]

            # A Hebrew year straddles two Gregorian years, so pad the Hebrew-year
            # search range by one on each side to avoid missing edge occurrences.
            start_bound = await self._gregorian_to_hebrew(session, start_year, 1, 1)
            end_bound = await self._gregorian_to_hebrew(session, end_year, 12, 31)
            if start_bound is None or end_bound is None:
                return [self._format_conversion_result(hebrew)]

            results = []
            for hy in range(start_bound["hy"] - 1, end_bound["hy"] + 2):
                occurrence = await self._hebrew_to_gregorian(session, hy, hebrew_month, hebrew_day)
                if occurrence is None:
                    continue
                if start_year <= occurrence["gy"] <= end_year:
                    results.append(self._format_conversion_result(occurrence))

            results.sort(key=lambda r: r["gregorian_date"])
            return results

    async def _gregorian_to_hebrew(self, session: aiohttp.ClientSession, gy: int, gm: int, gd: int) -> Optional[Dict]:
        """
        Call the Hebcal converter API to convert a Gregorian date to its Hebrew equivalent.
        """
        params = {
            "cfg": "json",
            "g2h": "1",
            "gy": gy,
            "gm": gm,
            "gd": gd,
        }
        try:
            async with session.get(HEBCAL_CONVERTER_URL, params=params) as response:
                if response.status != 200:
                    LOGGER.error(f"Hebcal converter (g2h) returned status {response.status} for {gy}-{gm}-{gd}")
                    return None
                return await response.json()
        except Exception as ex:
            LOGGER.error(f"Error converting Gregorian date {gy}-{gm}-{gd} to Hebrew: {ex}")
            return None

    async def _hebrew_to_gregorian(self, session: aiohttp.ClientSession, hy: int, hm: str, hd: int) -> Optional[Dict]:
        """
        Call the Hebcal converter API to convert a Hebrew date to its Gregorian equivalent.
        """
        params = {
            "cfg": "json",
            "h2g": "1",
            "hy": hy,
            "hm": hm,
            "hd": hd,
        }
        try:
            async with session.get(HEBCAL_CONVERTER_URL, params=params) as response:
                if response.status != 200:
                    LOGGER.error(f"Hebcal converter (h2g) returned status {response.status} for {hy} {hm} {hd}")
                    return None
                return await response.json()
        except Exception as ex:
            LOGGER.error(f"Error converting Hebrew date {hy} {hm} {hd} to Gregorian: {ex}")
            return None

    def _format_conversion_result(self, data: dict) -> dict:
        """
        Normalize a Hebcal converter API response into a consistent result dict.
        """
        return {
            "gregorian_date": date(data["gy"], data["gm"], data["gd"]),
            "hebrew_date": data.get("hebrew"),
            "hebrew_year": data.get("hy"),
            "hebrew_month": data.get("hm"),
            "hebrew_day": data.get("hd"),
            "after_sunset": data.get("afterSunset", False),
            "events": data.get("events", []),
        }


    def _parse_hebcal_response(self, data: dict) -> List:
        """
        Parse Hebcal API response into HolidayEvent objects.
        
        :param data: JSON response from Hebcal API
        :return: List of HolidayEvent objects
        """
        dates = []
        
        if "items" not in data:
            return dates
        
        for item in data["items"]:
            try:
                # Parse the date
                date_str = item.get("date")
                if not date_str:
                    continue
                
                date_obj = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                
                # Create holiday event
                event = {
                    "date": date_obj.date(),
                    "title": item.get("title", "Unknown"),
                    "category": item.get("category", ""),
                    "start": date_obj,
                    "end": date_obj,
                    "raw": {
                        "hebrew": item.get("hebrew"),
                        "link": item.get("link"),
                        "memo": item.get("memo"),
                        "yomtov": item.get("yomtov"),
                        "subcat": item.get("subcat"),
                    }
                }
                
                dates.append(event)
            except Exception as e:
                # Skip malformed entries
                LOGGER.error(f"Error parsing holiday item: {e}")
                continue
        
        return dates
       
    def _apply_filters(
        self,
        holidays: List,
        event: Optional[str],
        start_month: Optional[int],
        end_month: Optional[int]
    ) -> List:
        """
        Apply filters to holiday list.
        
        :param holidays: List of holidays to filter
        :param event: Event name filter (substring match)
        :param start_month: Starting month (1-12)
        :param end_month: Ending month (1-12)
        :return: Filtered list of holidays
        """
        filtered = holidays
        
        # Filter by event name
        if event:
            filtered = [
                h for h in filtered 
                if event.lower() in h['title'].lower()
            ]
        
        # Filter by month range
        if start_month is not None and end_month is not None:
            filtered = [
                h for h in filtered
                if start_month <= h['date'].month <= end_month
            ]
        elif start_month is not None:
            filtered = [
                h for h in filtered
                if h['date'].month >= start_month
            ]
        elif end_month is not None:
            filtered = [
                h for h in filtered
                if h['date'].month <= end_month
            ]
        
        # Sort by date
        filtered.sort(key=lambda h: h['date'])
        
        return filtered 